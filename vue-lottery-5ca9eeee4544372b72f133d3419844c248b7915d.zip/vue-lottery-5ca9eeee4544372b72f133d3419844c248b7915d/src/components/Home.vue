<script setup lang="ts">

</script>

<template>
  <div class="wrapper">
    <h1>Home</h1>
    <div class="horizontal-line"></div>
    <p>Головна сторінка цієї доповненої лабораторної</p>
  </div>
</template>

<style scoped>
.wrapper {
  display: flex;
  flex-direction: column;
  justify-content: center;
  align-items: center;
  margin-right: 20px;
  margin-left: 20px;
}

</style>