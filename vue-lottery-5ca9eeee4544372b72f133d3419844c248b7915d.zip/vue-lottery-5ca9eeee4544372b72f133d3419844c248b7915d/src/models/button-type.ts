export type ButtonType =
    'submit' |
    'reset' |
    'button';